<?php

return array(
    // Development time modules
    'modules' => array(
        'ZFTool',
        'ZendDeveloperTools',
    ),

    // Turn off caching
    'config_cache_enabled'     => false,
    'module_map_cache_enabled' => false,
);
